import java.util.*;

public class Principal {
	
	public static ArrayList<Objeto> llenarInventario(ArrayList<Objeto> candidatos, Inventario inventario) {
		// Desde este algoritmo se debe llamar a seleccionarCandidato() y a esCandidatoFactible()
		return null;
	}
	
	private static Objeto seleccionarCandidato(ArrayList<Objeto> candidatos) {

		return null;
	}
	
	private static boolean esCandidatoFactible(Objeto candidato, Inventario inventario) {

		return false;
	}

}
